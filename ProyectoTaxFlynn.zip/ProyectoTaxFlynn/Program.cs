﻿using System;
using ProyectoTaxFlynn.Models;

class Program
{
    static void Main()
    {
        // Datos de entrada
        int[] dataSISD = { 1, 2, 3, 4, 5 };
        int[] dataSIMD1 = { 1, 2, 3, 4, 5 };
        int[] dataSIMD2 = { 10, 20, 30, 40, 50 };
        int[] dataMIMD1 = { 1, 2, 3, 4, 5 };
        int[] dataMIMD2 = { 10, 20, 30, 40, 50 };

        // Ejecutar SISD
        int sisdResult = SISD.Process(dataSISD);
        Console.WriteLine($"SISD Resultado: {sisdResult}");

        // Ejecutar SIMD
        int[] simdResult = SIMD.Process(dataSIMD1, dataSIMD2);
        Console.WriteLine($"SIMD Resultado: [{string.Join(", ", simdResult)}]");

        // Ejecutar MIMD
        Console.WriteLine("MIMD Resultado:");
        MIMD.Process(dataMIMD1, dataMIMD2);
    }
}