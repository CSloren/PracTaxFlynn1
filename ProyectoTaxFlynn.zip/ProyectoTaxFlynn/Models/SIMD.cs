using System.Linq;

namespace ProyectoTaxFlynn.Models
{
    public static class SIMD
    {
        public static int[] Process(int[] data1, int[] data2)
        {
            
            return data1.Zip(data2, (a, b) => a + b).ToArray();
            
        }
    }
}