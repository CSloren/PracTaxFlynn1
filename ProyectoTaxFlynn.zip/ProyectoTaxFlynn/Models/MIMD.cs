using System;
using System.Threading.Tasks;

namespace ProyectoTaxFlynn.Models
{
    public static class MIMD
    {
        public static void Process(int[] data1, int[] data2)
        {

        
            // Crear tareas para diferentes operaciones
            Task task1 = Task.Run(() => ProcessData(data1, "cuadrado"));
            Task task2 = Task.Run(() => ProcessData(data2, "multiplicar"));

            // Esperar a que las tareas terminen
            Task.WaitAll(task1, task2);
        }

        private static void ProcessData(int[] data, string operation)
        {
            int[] result;
            if (operation == "cuadrado")
            {
                result = data.Select(x => x * x).ToArray();

            }
            else if (operation == "multiplicar")
            {
                result = data.Select(x => x * 10).ToArray();
                
            }

            else
            {
                result = data;
            }
            Console.WriteLine($"Resultado ({operation}): [{string.Join(", ", result)}]");
        }
    }
}