namespace ProyectoTaxFlynn.Models
{
    public static class SISD
    {
        public static int Process(int[] data)
        {
            int result = 0;
            foreach (int num in data)
            {
                
                result += num; // Operación secuencial

            }
            return result;
        }
    }
}